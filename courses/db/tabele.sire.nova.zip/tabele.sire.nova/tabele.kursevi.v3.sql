-----------------------------------------------------------------
-- SEMESTAR
-----------------------------------------------------------------
drop table semestar;

create table semestar (
       godina           smallint     not null,
       semestar         smallint     not null
             constraint chk_semestar check( 
                           semestar in (1,2)),
       primary          key(godina,semestar)
                      );



-----------------------------------------------------------------
-- KURS
-----------------------------------------------------------------
drop table kurs; 

create table kurs (
       id_predmeta      integer      not null,
       godina           smallint     not null,
       semestar         smallint     not null,
       primary          key(id_predmeta,godina,semestar),
       foreign          key fk_kurs_predmet(id_predmeta)
             references predmet              , 
       foreign          key fk_kurs_semestar(godina,semestar)
             references semestar       
                  );

create index kurs_semestar on kurs(godina,semestar,id_predmeta );



-----------------------------------------------------------------
-- UPISAN_KURS
-----------------------------------------------------------------
drop table upisan_kurs;

create table upisan_kurs (
       indeks           integer      not null,
       id_predmeta      integer      not null,
       godina           smallint     not null,
       semestar         smallint     not null,
       primary          key(indeks,id_predmeta,godina,semestar),       
       foreign          key fk_prk_kurs(id_predmeta,godina,semestar)
             references kurs                 ,
       foreign          key fk_prk_godina(indeks,godina)
             references upis_godine
                         );

create index upis_predmet on upisan_kurs(id_predmeta,godina,semestar,indeks);
create index upis_godina on upisan_kurs(godina,semestar,indeks,id_predmeta);
