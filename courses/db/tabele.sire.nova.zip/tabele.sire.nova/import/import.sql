import from nivoKvalifikacije.ixf of ixf
	commitcount 100
	insert_update into 
	nivo_kvalifikacije
;

import from smer.ixf of ixf
	commitcount 100
	insert_update into 
	smer
;

import from predmet.ixf of ixf
	commitcount 100
	insert_update into 
	predmet
;

import from uslovniPredmet.ixf of ixf
	commitcount 100
	replace into 
	uslovni_predmet
;

import from obavezanPredmet.ixf of ixf
	commitcount 100
	insert_update into 
	obavezan_predmet
;

import from dosije.ixf of ixf
	commitcount 50
	insert_update into 
	dosije
;

import from upisGodine.ixf of ixf
	commitcount 100
	insert_update into 
	upis_godine
;

import from semestar.ixf of ixf
	commitcount 100
	insert into 
	semestar
;

import from kurs.ixf of ixf
	commitcount 100
	insert into 
	kurs
;

import from upisan_kurs.ixf of ixf
	commitcount 100
	insert into 
	upisan_kurs
;

import from ispitni_rok.ixf of ixf
	commitcount 100
	insert_update into 
	ispitni_rok
;

import from ispit.ixf of ixf
	commitcount 100
	insert_update into 
	ispit
;