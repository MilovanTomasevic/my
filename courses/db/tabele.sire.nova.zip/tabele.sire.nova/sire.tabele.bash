echo Formiranje baze
db2 -t -f baza.sql

echo Formiram tabele planova
db2 -t -f tabele.planovi.v3.sql

echo Formiram tabele studenata
db2 -t -f tabele.studenti.v3.sql

echo Formiram tabele kurseva
db2 -t -f tabele.kursevi.v3.sql

echo Formiram tabele ispita
db2 -t -f tabele.ispiti.v3.sql

cd import

db2 -t -f import.sql

cd ..
