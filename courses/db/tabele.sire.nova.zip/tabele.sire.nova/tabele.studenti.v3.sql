----------------------------------------------------------------------
-- DOSIJE
----------------------------------------------------------------------
drop table dosije;

create table dosije (
       indeks           integer      not null,  
       id_smera         integer      not null,
       status           varchar(20)  not null
             constraint chk_status check( 
                        status in (
                           'budzet', 
                           'samofinansiranje',
                           'diplomirao', 
                           'mirovanje', 
                           'ispisan'  
                                  )     
                                        )    ,
       ime              varchar(10)  not null,
       prezime          varchar(15)  not null,
       pol              char         not null,
       jmbg             char(13)     not null,
       dat_rodjenja     date                 ,
       mesto_rodjenja   varchar(100)         ,
       drzava_rodjenja  varchar(100)         ,
       ime_oca          varchar(50)          ,
       ime_majke        varchar(50)          ,
       adr_ulica        varchar(100)         ,
       adr_broj         varchar(20)          ,
       adr_grad         varchar(100)         ,
       adr_postbroj     varchar(20)          ,
       adr_drzava       varchar(100)         ,
       adr_telefon      varchar(25)          ,
       adr_mobilnitel   varchar(25)          ,
       adr_email        varchar(50)          ,
       adr_wwwuri       varchar(100)         ,
       dat_upisa        date not null        ,
       primary key      (indeks)             ,
       foreign key      fk_dosije_smer(id_smera)
                        references smer
                    );

create index dos_smer on dosije(id_smera,indeks );

----------------------------------------------------------------------
-- UPIS_GODINE
----------------------------------------------------------------------
drop table upis_godine;

create table upis_godine (
       indeks           integer      not null,
       godina           smallint     not null
             constraint chk_godina check
               (godina between 1800 and 2100),
       status           varchar(20)  not null
             constraint chk_status check(
                        status in (
                           'budzet', 
                           'samofinansiranje'
                                  )
                                        )    ,
       dat_upisa        date         not null,
       upisano_bodova   smallint     not null
             constraint chk_upisbod check
           (upisano_bodova between 0 and 500),
       dat_overe        date                 ,
       overeno_bodova  smallint             ,
             constraint chk_overa check(
                 (
                  overeno_bodova is null
                  and dat_overe  is null
                 )
                 or
                 (
                  overeno_bodova is not null
                  and dat_overe  is not null
                  and dat_overe >= dat_upisa
                  and overeno_bodova between 0 and upisano_bodova
                 )
                                       )     ,
       primary key      (indeks,godina)      ,
       foreign key      fk_upis_dosije(indeks)
                        references dosije
                         );

create index upgo_status on upis_godine(status,godina,indeks);
create index upgo_godina on upis_godine(godina,status,indeks);
