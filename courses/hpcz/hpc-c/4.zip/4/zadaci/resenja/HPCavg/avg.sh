#!/bin/bash
date
hostname
echo "Compiling example"
mpicc -o avg avg.c
echo "Done."
echo "Running example:"
mpiexec -np 1 ${PWD}/avg
echo "Done."
date