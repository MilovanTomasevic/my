if (rank == 0) {
    int size = rand() % 10 + 1;
    char *message = (char *) calloc(size + 1, sizeof(char));

    for (int i = 0; i < size; i++) {
        message[i] = 'a';
    }
    
    MPI_Send(message, size + 1, MPI_CHAR, 1, 0, 
            MPI_COMM_WORLD);
    free(message);
} else {
    /* ... */
}