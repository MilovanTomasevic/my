if (rank == 0) {
    MPI_Request send_request;
    char *message = "Zdravo!";

    MPI_Issend(message, 8, MPI_CHAR, 1, 0, MPI_COMM_WORLD,
               &send_request);
    printf("Proces %d inicirao slanje poruke.\n", rank);

    printf("Proces radi nesto drugo dok se poruka salje.");

    int flag = 0;
    MPI_Test(&send_request, &flag, MPI_STATUS_IGNORE);
    if (flag != 0) /* poslato */ else /* nije */
} else /* ... */