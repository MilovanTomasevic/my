
// ...
if (rank == 0) {
    int message = 1;
    printf("Proces %d salje poruku procesu %d.\n", rank, 1);
    MPI_Send(&message, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
} else if (rank == 1) {
    int message;
    printf("Proces %d treba da primi poruku od procesa %d.\n",
            rank, 0);
    MPI_Recv(&message, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, NULL);
    printf("Proces %d primio poruku %d od procesa %d.\n", 
            rank, message, 0);
}
// ...