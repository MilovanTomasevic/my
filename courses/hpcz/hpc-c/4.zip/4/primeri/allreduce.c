int main(int argc, char *argv[]) {
    /* ... */

    int token = rank, result;
    MPI_Allreduce(&token, &result, 1, MPI_INT, 
                  MPI_SUM, MPI_COMM_WORLD);

    printf("Proces %d: result = %d.\n", rank, result);

    /* ... */

    return 0;
}