int main(int argc, char *argv[]) {
    int *data = NULL, *partial_data = NULL;
    int piecelen = datalen / size;
    partial_data = (int *) malloc(sizeof(int) * piecelen);
    /* ... */

    if (rank == root)
        data = (int *) malloc(sizeof(int) * datalen);

    MPI_Gather(partial_data, piecelen, MPI_INT, data, 
               piecelen, MPI_INT, root, MPI_COMM_WORLD);

    /* ... */

    return 0;
}