int main(int argc, char *argv[]) {
    /* ... */

    int *data = NULL, *partial_data = NULL;
    int piecelen = datalen / size;
    if (rank == root) {
        /* inicijalizacija data niza */
    }
    partial_data = (int *) malloc(sizeof(int) * piecelen);

    MPI_Scatter(data, piecelen, MPI_INT, partial_data, 
                piecelen, MPI_INT, root, MPI_COMM_WORLD);

    /* ... */
    return 0;
}