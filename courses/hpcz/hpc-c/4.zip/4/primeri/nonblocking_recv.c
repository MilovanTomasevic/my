if (rank == 0) /* ... */
} else {
    MPI_Request receive_request;
    char message[8];

    MPI_Irecv(message, 8, MPI_CHAR, 0, 0, MPI_COMM_WORLD,
              &receive_request);
    printf("Proces %d inicirao primanje poruke.\n", rank);

    printf("Proces radi nesto drugo dok se poruka prima...");

    MPI_Wait(&receive_request, MPI_STATUS_IGNORE);
    printf("Proces %d primio poruku: \"%s\"\n", rank, message);
}