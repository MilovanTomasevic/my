int main(int argc, char *argv[]) {
    /* ... */

   int token = rank, result;
    MPI_Reduce(&token, &result, 1, MPI_INT, 
               MPI_SUM, root, MPI_COMM_WORLD);

    printf("Proces %d: result = %d.\n", rank, result);

    MPI_Finalize();

    return 0;
}