int main(int argc, char *argv[]) {

    /* ... */

    int *data = (int *) malloc(sizeof(int) * size);

    int token = rank;
    MPI_Allgather(&token, 1, MPI_INT, data, 
                  1, MPI_INT, MPI_COMM_WORLD);

    free(data);

    /* ... */

    return 0;
}