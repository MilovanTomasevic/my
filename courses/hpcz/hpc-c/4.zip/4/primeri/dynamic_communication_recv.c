if (rank == 0) {
    /* ... */
} else {
    MPI_Status status; int size;
    MPI_Probe(0, 0, MPI_COMM_WORLD, &status);
    MPI_Get_count(&status, MPI_CHAR, &size);

    char *message = (char *) malloc(size * sizeof(char));
    MPI_Recv(message, size, MPI_CHAR, 0, 0, MPI_COMM_WORLD, 
            MPI_STATUS_IGNORE);

    printf("Primljena poruka: %s.\n", message);
}