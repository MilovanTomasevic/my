#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#ifndef DISABLE_HDF5
#include "utils/h5_matrix_utils.h"
#endif

#define MFILENAME "../input_data/m3x3.h5"   // modifikovati putanju po potrebi
#define VFILENAME "../input_data/v3x1.h5"   // modifikovati putanju po potrebi

// TODO implementirati sekvencijalnu varijantu mnozenja matrice i vektora.
// Dodati potrebne parametre i u main-u meriti vreme izvrsavanja.
// Za merenje vremena koristiti funkciju MPI_Wtime().
void matrix_vector_multiply();

// TODO implementirati OpenMPI varijantu mnozenja matrice i vektora.
// Dodati potrebne parametre i u main-u meriti vreme izvrsavanja.
// U main-u ispisati oba vremena izvrsavanja.
// Za merenje vremena koristiti funkciju MPI_Wtime().
void matrix_vector_multiply_mpi();

int main() {
    
    float *matrix = NULL, *vector = NULL;
    unsigned long long mrows, mcols, vrows, vcols;
    
#ifndef DISABLE_HDF5
    printf("Matrica:\n");
    matrix = h5_load_matrix(MFILENAME, &mrows, &mcols);
    print_float_matrix(matrix, mrows, mcols);
    assert(matrix != NULL);
#else
    printf("HDF podrska onemogucena!\n");
#endif

#ifndef DISABLE_HDF5
    printf("Vektor:\n");
    vector = h5_load_matrix(VFILENAME, &vrows, &vcols);
    print_float_vector(vector, vrows);
    assert(vector != NULL);
#else
    printf("HDF podrska onemogucena!\n");
#endif
    
    if (vector != NULL) free(vector);
    if (matrix != NULL) free(matrix);
    
    return 0;
}