#include <mpi.h>
#include <stdio.h>

void main(int argc, char* argv[])
{
  int id = 0;
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &id);
  printf("Hello world from %d\n", id);
  MPI_Finalize();
}
